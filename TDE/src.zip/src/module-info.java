/**
 * 
 */
/**
 * 
 */
module TDE_01 {
	requires java.desktop;
}