package model;

public class ModelException extends Exception{
	public ModelException(String textoDoErro) {
		super(textoDoErro);
	}
}
