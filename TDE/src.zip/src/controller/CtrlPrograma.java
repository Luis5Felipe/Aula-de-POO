package controller;

import viewer.JanelaPrincipal;

public class CtrlPrograma {
	public static void main(String[] args) {
		new JanelaPrincipal();
	}
}
